/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.oscarssoftware.clases;

import java.util.ArrayList;

/**
 *
 * @author Anibal
 */
public interface sentencias {
    ArrayList consulta();
    boolean insertar();
    boolean borrar();
    boolean modificar();
}
